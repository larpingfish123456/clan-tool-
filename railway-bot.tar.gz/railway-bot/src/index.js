import "dotenv/config";
import { Client, GatewayIntentBits, Partials } from "discord.js";
import { initDb } from "./db.js";
import { deployCommands } from "./commands/index.js";
import { handleMessageCreate } from "./messageCreate.js";
import {
  handleSetupEntries, handleRoleSetup, handleSetupUpdates,
  handleSchedule, handleScheduleModal,
  handleHostTourney, handleHostTourneyModal,
  handleBracket, handleThreads, handleUpdate,
  handleOver, handleRefresh, handleListEntries,
  handleSetPlayers, handleSyncRoles,
  handleClanMake, handleClanMakeModal,
  handleClanRoster, handleUpdateClan, handleUpdateClanModal,
  handleInvite,
} from "./handlers.js";

const TOKEN = process.env.DISCORD_BOT_TOKEN;
if (!TOKEN) { console.error("[Fatal] DISCORD_BOT_TOKEN is not set in .env"); process.exit(1); }

await initDb();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel],
});

const commandMap = {
  "setup-entries-2": handleSetupEntries,
  "role-setup-2":    handleRoleSetup,
  "schedule-2":      handleSchedule,
  "host-tourney-2":  handleHostTourney,
  "setup-updates-2": handleSetupUpdates,
  "bracket-2":       handleBracket,
  "threads-2":       handleThreads,
  "update-2":        handleUpdate,
  "over-2":          handleOver,
  "refresh-2":       handleRefresh,
  "list-entries-2": handleListEntries,
  "set-players-2":   handleSetPlayers,
  "sync-roles-2":    handleSyncRoles,
  "clan-make-2":     handleClanMake,
  "clan-roster-2":   handleClanRoster,
  "update-clan-2":   handleUpdateClan,
  "invite-2":        handleInvite,
};

client.once("clientReady", async (c) => {
  console.log(`[Bot] Logged in as ${c.user.tag}`);
  try { await deployCommands(c.user.id); } catch (e) { console.error("[Bot] Command deploy failed:", e.message); }
});

client.on("messageCreate", async (msg) => {
  try { await handleMessageCreate(msg); } catch (e) { console.error("[Bot] messageCreate error:", e); }
});

client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const handler = commandMap[interaction.commandName];
      if (handler) await handler(interaction);
    } else if (interaction.isModalSubmit()) {
      if (interaction.customId === "schedule_modal") await handleScheduleModal(interaction);
      else if (interaction.customId === "host_tourney_modal") await handleHostTourneyModal(interaction);
      else if (interaction.customId === "clan_make_modal") await handleClanMakeModal(interaction);
      else if (interaction.customId === "update_clan_modal") await handleUpdateClanModal(interaction);
    }
  } catch (e) {
    console.error("[Bot] interaction error:", e);
    const msg = { content: "❌ An error occurred.", ephemeral: true };
    if (interaction.replied || interaction.deferred) interaction.followUp(msg).catch(() => {});
    else interaction.reply(msg).catch(() => {});
  }
});

client.on("error", (e) => console.error("[Bot] Client error:", e));

await client.login(TOKEN);
