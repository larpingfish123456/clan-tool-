import { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ChannelType, PermissionFlagsBits, OAuth2Scopes } from "discord.js";
import { query, getGuildSettings, upsertGuildSettings } from "./db.js";

// ── helpers ──────────────────────────────────────────────────────────────────

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function buildBracket(players) {
  const nextPow2 = Math.pow(2, Math.ceil(Math.log2(Math.max(players.length, 2))));
  const seeded = shuffleArray(players);
  const byes = nextPow2 - seeded.length;
  const firstRound = [];
  let matchIndex = 0, playerIdx = 0;
  for (let i = 0; i < nextPow2 / 2; i++) {
    const p1 = seeded[playerIdx++] ?? null;
    const hasBye = i < byes;
    const p2 = hasBye ? null : (seeded[playerIdx++] ?? null);
    firstRound.push({ matchIndex: matchIndex++, player1: p1, player2: p2, winner: hasBye ? p1 : null, isBye: hasBye });
  }
  const rounds = [{ roundNumber: 1, matches: firstRound }];
  let prev = firstRound, roundNum = 2;
  while (prev.length > 1) {
    const next = [];
    for (let i = 0; i < prev.length; i += 2)
      next.push({ matchIndex: matchIndex++, player1: null, player2: null, winner: null, isBye: false });
    rounds.push({ roundNumber: roundNum++, matches: next });
    prev = next;
  }
  return rounds;
}

function renderBracketEmbed(rounds, title) {
  const fields = rounds.map(round => ({
    name: `Round ${round.roundNumber}`,
    value: round.matches.map(m => {
      if (m.isBye) return `**BYE** → <@${m.player1}> \u2705`;
      const p1 = m.player1 ? `<@${m.player1}>` : "*TBD*";
      const p2 = m.player2 ? `<@${m.player2}>` : "*TBD*";
      return `${p1} **vs** ${p2}${m.winner ? ` \u2192 <@${m.winner}> \ud83c\udfc6` : ""}`;
    }).join("\n") || "*No matches*",
    inline: false,
  }));
  return { color: 0xeb459e, title: `\ud83c\udfaf Bracket \u2014 ${title}`, fields, footer: { text: "Use /update-2 to advance players \u2022 /threads-2 to create match threads" }, timestamp: new Date().toISOString() };
}

function getFieldValue(interaction, customId) { try { return interaction.fields.getTextInputValue(customId); } catch { return null; } }

// ── command handlers ──────────────────────────────────────────────────────────

export async function handleSetupEntries(interaction) {
  const channel = interaction.options.getChannel("channel", true);
  await upsertGuildSettings(interaction.guildId, { entry_channel_id: channel.id });
  await interaction.reply({ embeds: [{ color: 0x57f287, title: "\u2705 Entry Channel Set", description: `<#${channel.id}> is now the entry channel. Players register by mentioning themselves/teammates there.`, footer: { text: "Use /role-setup-2 to set the registration role" } }], ephemeral: true });
}

export async function handleRoleSetup(interaction) {
  const role = interaction.options.getRole("role", true);
  await upsertGuildSettings(interaction.guildId, { registered_role_id: role.id });
  await interaction.reply({ embeds: [{ color: 0x57f287, title: "\u2705 Registration Role Set", description: `Players will receive <@&${role.id}> on registration.` }], ephemeral: true });
}

export async function handleSetupUpdates(interaction) {
  const channel = interaction.options.getChannel("channel", true);
  await upsertGuildSettings(interaction.guildId, { updates_channel_id: channel.id });
  await interaction.reply({ embeds: [{ color: 0x57f287, title: "\u2705 Updates Channel Set", description: `Brackets and announcements will be posted in <#${channel.id}>.` }], ephemeral: true });
}

export async function handleSchedule(interaction) {
  const modal = new ModalBuilder().setCustomId("schedule_modal").setTitle("Weekly Tournament Schedule");
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("week_label").setLabel("Week Title").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("RCL #7 | Week 1 Of June 2026")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("event1").setLabel("Event 1").setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder("June 2nd | Tuesday | 23:00 FLASH | 1,500 | 1v1 DL | 32/64 | N/A")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("event2").setLabel("Event 2 (optional)").setStyle(TextInputStyle.Paragraph).setRequired(false).setPlaceholder("June 4th | Thursday | 23:00 FLASH 2v2 | 3,000 | 2v2 DL | 16/32 | R16")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("event3").setLabel("Event 3 (optional)").setStyle(TextInputStyle.Paragraph).setRequired(false).setPlaceholder("June 6th | Saturday | 23:00 GRAND FINALS | 6,000 | 3v3 | 8/16 | R16")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("event4").setLabel("Event 4 (optional)").setStyle(TextInputStyle.Paragraph).setRequired(false).setPlaceholder("June 8th | Monday | 23:00 SQUADS | 4,000 | 4v4 | 8/16 | N/A")),
  );
  await interaction.showModal(modal);
}

export async function handleScheduleModal(interaction) {
  const weekLabel = getFieldValue(interaction, "week_label") ?? "";
  const events = [
    getFieldValue(interaction, "event1"),
    getFieldValue(interaction, "event2"),
    getFieldValue(interaction, "event3"),
    getFieldValue(interaction, "event4"),
  ].filter(Boolean);
  if (!events.length) return interaction.reply({ content: "\u274c No valid events provided.", ephemeral: true });
  const rawContent = events.join("\n\n---\n\n");
  await query("INSERT INTO schedules (guild_id, week_label, content) VALUES ($1, $2, $3)", [interaction.guildId, weekLabel, rawContent]);
  const description = events.join("\n\n");
  const embed = { color: 0xffd700, title: `\u2b50 ${weekLabel} Schedule! \u2b50`, description, footer: { text: "Stay tuned for more updates!" }, timestamp: new Date().toISOString() };
  const settings = await getGuildSettings(interaction.guildId);
  const ch = settings?.updates_channel_id ? interaction.guild?.channels.cache.get(settings.updates_channel_id) : null;
  if (ch && "send" in ch) { await ch.send({ embeds: [embed] }); await interaction.reply({ content: `\u2705 Schedule posted in <#${ch.id}>`, ephemeral: true }); }
  else await interaction.reply({ embeds: [embed] });
}

export async function handleHostTourney(interaction) {
  const modal = new ModalBuilder().setCustomId("host_tourney_modal").setTitle("Host a Tournament");
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("title").setLabel("Tournament Name").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("3v3 Normal Tournament [Default Loadout]")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("tournament_info").setLabel("Tournament Info").setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder("Date/Time: June 14, 23:00 EST\nFormat: 3v3 Default Loadout\nRank Cap: R16\nMax Teams: 32")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("entry_format").setLabel("Entry Format").setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder("@discordusername roblox_username @discordusername roblox_username")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("regulations").setLabel("Tournament Regulations").setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder("Exploiting accusations must have validated recording.\nDo not enter with unwilling players.")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("player_count").setLabel("How many players per team?").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("3 (for 3v3), 1 (for 1v1), etc."))
  );
  await interaction.showModal(modal);
}

export async function handleHostTourneyModal(interaction) {
  const { ButtonBuilder, ButtonStyle } = await import("discord.js");
  const title = getFieldValue(interaction, "title") ?? "";
  const tournamentInfo = getFieldValue(interaction, "tournament_info") ?? "";
  const entryFormat = getFieldValue(interaction, "entry_format") ?? "";
  const regulationsRaw = getFieldValue(interaction, "regulations") ?? "";
  const playerCount = getFieldValue(interaction, "player_count") ?? "";
  const maxMatch = tournamentInfo.match(/max\s*teams?[\s:\-|=]*([\d]+)/i);
  const maxPlayers = maxMatch ? parseInt(maxMatch[1]) : 16;
  const dateMatch = tournamentInfo.match(/date\s*[/\-]?\s*time[\s:\-|=]*(.+)/i);
  const tournamentTime = dateMatch ? dateMatch[1].trim() : null;
  const rankMatch = tournamentInfo.match(/rank\s*cap[\s:\-|=]*(.+)/i);
  const rankCap = rankMatch ? rankMatch[1].trim() : null;
  const res = await query("INSERT INTO tournaments (guild_id, title, tournament_time, region, prize, rank_cap, max_players, status) VALUES ($1,$2,$3,$4,$5,$6,$7,'open') RETURNING id", [interaction.guildId, title, tournamentTime, null, null, rankCap, maxPlayers]);
  const tournamentId = res.rows[0].id;
  await upsertGuildSettings(interaction.guildId, { active_tournament_id: tournamentId });
  const settings = await getGuildSettings(interaction.guildId);
  const parts = [`\`\`\``, `   Tournament Information   `, `\`\`\``, tournamentInfo];
  if (playerCount.trim()) parts.push(``, `\u2022 **Players per team:** ${playerCount}`);
  parts.push(``, `\`\`\``, `   Tournament Regulations   `, `\`\`\``, regulationsRaw, ``, `\`\`\``, `   Entry Format   `, `\`\`\``, entryFormat);
  const description = parts.join("\n");
  const embed = { color: 0x5865f2, title: `\ud83c\udfc6 ${title} \ud83c\udfc6`, description, footer: { text: `Tournament #${tournamentId} \u2014 Entries open! \u2022 After winning, make a ticket in #support` }, timestamp: new Date().toISOString() };
  const components = [];
  if (settings?.entry_channel_id) {
    const btn = new ButtonBuilder().setLabel("Click Here to enter your team!").setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${interaction.guildId}/${settings.entry_channel_id}`).setEmoji("\ud83c\udfc6");
    components.push(new ActionRowBuilder().addComponents(btn));
  }
  const payload = { embeds: [embed], ...(components.length ? { components } : {}) };
  const ch = settings?.updates_channel_id ? interaction.guild?.channels.cache.get(settings.updates_channel_id) : null;
  if (ch && "send" in ch) { await ch.send(payload); await interaction.reply({ content: `\u2705 Tournament **${title}** (#${tournamentId}) announced in <#${ch.id}>!`, ephemeral: true }); }
  else await interaction.reply(payload);
}

export async function handleBracket(interaction) {
  await interaction.deferReply();
  const settings = await getGuildSettings(interaction.guildId);
  if (!settings?.active_tournament_id) return interaction.editReply({ content: "\u274c No active tournament. Use `/host-tourney-2` or `/refresh-2`." });
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1", [settings.active_tournament_id]);
  const tourney = tourneyRes.rows[0];
  if (!tourney) return interaction.editReply({ content: "\u274c Tournament not found." });
  const entriesRes = await query("SELECT * FROM entries WHERE tournament_id = $1 ORDER BY registered_at ASC", [settings.active_tournament_id]);
  if (entriesRes.rows.length < 2) return interaction.editReply({ content: `\u274c Need at least 2 players. Currently: **${entriesRes.rows.length}**` });
  const players = entriesRes.rows.map(e => e.leader_id);
  const rounds = buildBracket(players);
  const existing = await query("SELECT id FROM brackets WHERE tournament_id = $1 AND guild_id = $2", [settings.active_tournament_id, interaction.guildId]);
  let bracketId;
  if (existing.rows.length > 0) { bracketId = existing.rows[0].id; await query("UPDATE brackets SET rounds = $1, current_round = 1, updated_at = NOW() WHERE id = $2", [JSON.stringify(rounds), bracketId]); }
  else { const r = await query("INSERT INTO brackets (tournament_id, guild_id, rounds) VALUES ($1,$2,$3) RETURNING id", [settings.active_tournament_id, interaction.guildId, JSON.stringify(rounds)]); bracketId = r.rows[0].id; }
  const embed = renderBracketEmbed(rounds, tourney.title);
  const ch = settings.updates_channel_id ? interaction.guild?.channels.cache.get(settings.updates_channel_id) : null;
  if (ch && "send" in ch && ch.id !== interaction.channelId) { await ch.send({ embeds: [embed] }); await interaction.editReply({ content: `\u2705 Bracket generated (${players.length} players) and posted in <#${ch.id}>!` }); }
  else await interaction.editReply({ embeds: [embed] });
}

export async function handleThreads(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const settings = await getGuildSettings(interaction.guildId);
  if (!settings?.active_tournament_id) return interaction.editReply({ content: "\u274c No active tournament." });
  const bracketRes = await query("SELECT * FROM brackets WHERE tournament_id = $1 AND guild_id = $2", [settings.active_tournament_id, interaction.guildId]);
  if (!bracketRes.rows.length) return interaction.editReply({ content: "\u274c No bracket found. Run `/bracket-2` first." });
  const bracket = bracketRes.rows[0];
  const rounds = bracket.rounds;
  const currentRound = rounds.find(r => r.roundNumber === bracket.current_round);
  if (!currentRound) return interaction.editReply({ content: "\u274c Could not find the current round." });
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1", [settings.active_tournament_id]);
  const tourney = tourneyRes.rows[0];
  const created = [];
  for (const match of currentRound.matches) {
    if (match.isBye || match.winner || !match.player1 || !match.player2) continue;
    const existing = await query("SELECT thread_id FROM bracket_threads WHERE bracket_id = $1 AND match_index = $2 AND round_number = $3", [bracket.id, match.matchIndex, currentRound.roundNumber]);
    if (existing.rows.length > 0) { created.push(`Thread already exists for Match ${match.matchIndex + 1}`); continue; }
    try {
      const thread = await interaction.channel.threads.create({ name: `R${currentRound.roundNumber} Match ${match.matchIndex + 1} \u2014 ${tourney.title}`, type: ChannelType.PublicThread, reason: "Tournament match thread" });
      await query("INSERT INTO bracket_threads (bracket_id, match_index, round_number, thread_id) VALUES ($1,$2,$3,$4)", [bracket.id, match.matchIndex, currentRound.roundNumber, thread.id]);
      await thread.send({ content: `<@${match.player1}> <@${match.player2}>`, embeds: [{ color: 0x5865f2, title: `\u2694\ufe0f Round ${currentRound.roundNumber} \u2014 Match ${match.matchIndex + 1}`, description: `**${tourney.title}**\n\n<@${match.player1}> **vs** <@${match.player2}>\n\nGood luck! An admin will use \`/update-2\` to record the winner.`, footer: { text: "May the best player win!" } }] });
      created.push(`\u2705 <#${thread.id}> \u2014 <@${match.player1}> vs <@${match.player2}>`);
    } catch { created.push(`\u274c Failed for Match ${match.matchIndex + 1}`); }
  }
  if (!created.length) return interaction.editReply({ content: "No active matches in the current round." });
  await interaction.editReply({ embeds: [{ color: 0x57f287, title: `\ud83e\uddf5 Threads Created \u2014 Round ${currentRound.roundNumber}`, description: created.join("\n") }] });
}

export async function handleUpdate(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const matchNum = interaction.options.getInteger("match", true);
  const winner = interaction.options.getUser("winner", true);
  const settings = await getGuildSettings(interaction.guildId);
  if (!settings?.active_tournament_id) return interaction.editReply({ content: "\u274c No active tournament." });
  const bracketRes = await query("SELECT * FROM brackets WHERE tournament_id = $1 AND guild_id = $2", [settings.active_tournament_id, interaction.guildId]);
  if (!bracketRes.rows.length) return interaction.editReply({ content: "\u274c No bracket found. Run `/bracket-2` first." });
  const bracket = bracketRes.rows[0];
  const rounds = bracket.rounds;
  const matchIndex = matchNum - 1;
  let foundMatch = null, foundRound = null, matchPos = -1;
  for (const round of rounds) {
    for (let i = 0; i < round.matches.length; i++) {
      if (round.matches[i].matchIndex === matchIndex) { foundMatch = round.matches[i]; foundRound = round; matchPos = i; break; }
    }
    if (foundMatch) break;
  }
  if (!foundMatch) return interaction.editReply({ content: `\u274c Match #${matchNum} not found.` });
  if (foundMatch.winner) return interaction.editReply({ content: `\u274c Match #${matchNum} already decided: <@${foundMatch.winner}>` });
  if (foundMatch.player1 !== winner.id && foundMatch.player2 !== winner.id) return interaction.editReply({ content: `\u274c <@${winner.id}> is not in Match #${matchNum}.` });
  foundMatch.winner = winner.id;
  const nextRoundIdx = rounds.findIndex(r => r.roundNumber === foundRound.roundNumber + 1);
  if (nextRoundIdx !== -1) {
    const nextMatch = rounds[nextRoundIdx].matches[Math.floor(matchPos / 2)];
    if (nextMatch) { if (matchPos % 2 === 0) nextMatch.player1 = winner.id; else nextMatch.player2 = winner.id; }
  }
  const allDone = rounds[rounds.findIndex(r => r.roundNumber === foundRound.roundNumber)].matches.every(m => m.winner !== null || m.isBye);
  const newCurrent = allDone ? Math.min(foundRound.roundNumber + 1, rounds.length) : bracket.current_round;
  await query("UPDATE brackets SET rounds = $1, current_round = $2, updated_at = NOW() WHERE id = $3", [JSON.stringify(rounds), newCurrent, bracket.id]);
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1", [settings.active_tournament_id]);
  const tourney = tourneyRes.rows[0];
  const embed = renderBracketEmbed(rounds, tourney.title);
  const ch = settings.updates_channel_id ? interaction.guild?.channels.cache.get(settings.updates_channel_id) : null;
  const advanceMsg = allDone && newCurrent < rounds.length ? `\n\n\ud83d\udce2 Round ${foundRound.roundNumber} complete! Run \`/threads-2\` for Round ${newCurrent} threads.` : "";
  if (ch && "send" in ch) { await ch.send({ embeds: [embed] }); await interaction.editReply({ content: `\u2705 <@${winner.id}> advances from Match #${matchNum}!${advanceMsg} Updated bracket in <#${ch.id}>.` }); }
  else await interaction.editReply({ content: `\u2705 <@${winner.id}> advances!${advanceMsg}`, embeds: [embed] });
}

export async function handleOver(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const settings = await getGuildSettings(interaction.guildId);
  if (!settings?.active_tournament_id) return interaction.editReply({ content: "\u274c No active tournament." });
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1", [settings.active_tournament_id]);
  const tourney = tourneyRes.rows[0];
  const bracketRes = await query("SELECT * FROM brackets WHERE tournament_id = $1 AND guild_id = $2", [settings.active_tournament_id, interaction.guildId]);
  let champion = null;
  if (bracketRes.rows.length > 0) {
    const bracket = bracketRes.rows[0];
    const rounds = bracket.rounds;
    champion = rounds[rounds.length - 1]?.matches[0]?.winner ?? null;
    const threadRes = await query("SELECT thread_id FROM bracket_threads WHERE bracket_id = $1", [bracket.id]);
    for (const row of threadRes.rows) {
      try { const t = interaction.guild?.channels.cache.get(row.thread_id); if (t && "setArchived" in t) await t.setArchived(true); } catch (_) {}
    }
    await query("DELETE FROM bracket_threads WHERE bracket_id = $1", [bracket.id]);
    await query("DELETE FROM brackets WHERE id = $1", [bracket.id]);
  }
  await query("UPDATE tournaments SET status = 'closed' WHERE id = $1", [settings.active_tournament_id]);
  await upsertGuildSettings(interaction.guildId, { active_tournament_id: null });
  const embed = { color: 0xffd700, title: `\ud83c\udfc6 Tournament Over \u2014 ${tourney.title}`, description: champion ? `Congratulations to <@${champion}> for winning **${tourney.title}**! \ud83c\udf89\n\nThank you to everyone who participated!` : `**${tourney.title}** has concluded. Thank you all!`, fields: [{ name: "Status", value: "Closed \u2705", inline: true }, ...(champion ? [{ name: "\ud83e\udd47 Champion", value: `<@${champion}>`, inline: true }] : [])], footer: { text: "Use /host-tourney-2 to start a new tournament" }, timestamp: new Date().toISOString() };
  const ch = settings.updates_channel_id ? interaction.guild?.channels.cache.get(settings.updates_channel_id) : null;
  if (ch && "send" in ch) { await ch.send({ embeds: [embed] }); await interaction.editReply({ content: `\u2705 Tournament ended. Results posted in <#${ch.id}>.` }); }
  else await interaction.editReply({ content: "\u2705 Tournament ended!", embeds: [embed] });
}

export async function handleRefresh(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const tournamentId = interaction.options.getInteger("tournament_id", true);
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1 AND guild_id = $2", [tournamentId, interaction.guildId]);
  if (!tourneyRes.rows.length) {
    const allRes = await query("SELECT id, title, status FROM tournaments WHERE guild_id = $1 ORDER BY created_at DESC LIMIT 10", [interaction.guildId]);
    const list = allRes.rows.map(t => `\u2022 **#${t.id}** \u2014 ${t.title} (${t.status})`).join("\n");
    return interaction.editReply({ content: `\u274c Tournament #${tournamentId} not found.\n\n**Available:**\n${list || "*None*"}` });
  }
  const tourney = tourneyRes.rows[0];
  const countRes = await query("SELECT COUNT(*) as count FROM entries WHERE tournament_id = $1", [tournamentId]);
  await upsertGuildSettings(interaction.guildId, { active_tournament_id: tournamentId });
  await interaction.editReply({ embeds: [{ color: 0x57f287, title: "\ud83d\udd04 Active Tournament Updated", description: `Now using **${tourney.title}** (#${tournamentId}) as the active tournament.`, fields: [{ name: "Status", value: tourney.status, inline: true }, { name: "Players", value: `${countRes.rows[0].count}`, inline: true }, { name: "Time", value: tourney.tournament_time ?? "N/A", inline: true }], footer: { text: "Run /bracket-2 to regenerate the bracket" } }] });
}

export async function handleSyncRoles(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const settings = await getGuildSettings(interaction.guildId);
  const tournamentId = interaction.options.getInteger("tournament_id") ?? settings?.active_tournament_id;
  const messageId = interaction.options.getString("message_id", true);
  if (!tournamentId) return interaction.editReply({ content: "\u274c No tournament ID provided and no active tournament." });
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1 AND guild_id = $2", [tournamentId, interaction.guildId]);
  if (!tourneyRes.rows.length) return interaction.editReply({ content: `\u274c Tournament #${tournamentId} not found.` });
  const roleId = settings?.registered_role_id;
  if (!roleId) return interaction.editReply({ content: "\u274c No registered role set. Use /role-setup-2 first." });
  const entriesRes = await query("SELECT * FROM entries WHERE tournament_id = $1 AND message_id >= $2", [tournamentId, messageId]);
  const entries = entriesRes.rows;
  if (!entries.length) return interaction.editReply({ content: `\u274c No entries found for tournament #${tournamentId} at or after message ID \`${messageId}\`.` });
  const guild = interaction.guild;
  if (!guild) return interaction.editReply({ content: "\u274c Guild not available." });
  let assigned = 0; let failed = 0; const failedUsers = [];
  for (const entry of entries) {
    const userIds = [entry.leader_id, ...(entry.team_members || [])];
    for (const userId of userIds) {
      try { const member = await guild.members.fetch(userId); if (!member.roles.cache.has(roleId)) { await member.roles.add(roleId); assigned++; } } catch (err) { failed++; failedUsers.push(`<@${userId}>`); }
    }
  }
  const tourney = tourneyRes.rows[0];
  const fields = [{ name: "\ud83d\udc65 Players Processed", value: `${entries.length}`, inline: true }, { name: "\u2705 Roles Added", value: `${assigned}`, inline: true }, { name: "\u274c Failed", value: `${failed}`, inline: true }];
  if (failedUsers.length > 0) { const uniqueFailed = [...new Set(failedUsers)].slice(0, 10); fields.push({ name: "Failed Users", value: uniqueFailed.join(" ") + (failedUsers.length > 10 ? " ..." : ""), inline: false }); }
  await interaction.editReply({ embeds: [{ color: 0x57f287, title: "\ud83d\udd04 Roles Synced", description: `Synced roles for **${tourney.title}** (#${tournamentId})\nEntries from message ID: \`${messageId}\` and above`, fields, timestamp: new Date().toISOString() }] });
}

export async function handleSetPlayers(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const newMax = interaction.options.getInteger("max_players", true);
  const settings = await getGuildSettings(interaction.guildId);
  const tournamentId = interaction.options.getInteger("tournament_id") ?? settings?.active_tournament_id;
  if (!tournamentId) return interaction.editReply({ content: "\u274c No tournament ID provided and no active tournament." });
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1 AND guild_id = $2", [tournamentId, interaction.guildId]);
  if (!tourneyRes.rows.length) return interaction.editReply({ content: `\u274c Tournament #${tournamentId} not found.` });
  const tourney = tourneyRes.rows[0];
  const oldMax = tourney.max_players;
  const entriesRes = await query("SELECT COUNT(*) as count FROM entries WHERE tournament_id = $1", [tournamentId]);
  const currentEntries = parseInt(entriesRes.rows[0].count);
  const newStatus = currentEntries >= newMax ? "full" : "open";
  await query("UPDATE tournaments SET max_players = $1, status = $2 WHERE id = $3", [newMax, newStatus, tournamentId]);
  const statusNote = newStatus === "full" ? "\ud83d\udd34 **Status:** Tournament is now full!" : `\ud83d\udfe2 **Status:** Open (${currentEntries} / ${newMax} entries)`;
  await interaction.editReply({ embeds: [{ color: 0x57f287, title: "\u2705 Max Players Updated", description: `**${tourney.title}** (#${tournamentId})`, fields: [{ name: "Before", value: `${oldMax}`, inline: true }, { name: "After", value: `${newMax}`, inline: true }, { name: "Current Entries", value: `${currentEntries}`, inline: true }], footer: { text: statusNote }, timestamp: new Date().toISOString() }] });
}

export async function handleListEntries(interaction) {
  await interaction.deferReply();
  const settings = await getGuildSettings(interaction.guildId);
  const tournamentId = interaction.options.getInteger("tournament_id") ?? settings?.active_tournament_id;
  if (!tournamentId) return interaction.editReply({ content: "\u274c No active tournament." });
  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1 AND guild_id = $2", [tournamentId, interaction.guildId]);
  if (!tourneyRes.rows.length) return interaction.editReply({ content: `\u274c Tournament #${tournamentId} not found.` });
  const tourney = tourneyRes.rows[0];
  const entriesRes = await query("SELECT * FROM entries WHERE tournament_id = $1 ORDER BY registered_at ASC", [tournamentId]);
  const entries = entriesRes.rows;
  if (!entries.length) return interaction.editReply({ embeds: [{ color: 0x5865f2, title: `\ud83d\udccb Entries \u2014 ${tourney.title}`, description: "No players registered yet.", fields: [{ name: "Status", value: tourney.status, inline: true }, { name: "Max Players", value: `${tourney.max_players}`, inline: true }] }] });
  const spotsLeft = tourney.max_players - entries.length;
  const statusEmoji = tourney.status === "open" ? "\ud83d\udfe2" : tourney.status === "full" ? "\ud83d\udd34" : "\u26ab";
  const lines = entries.map((e, i) => { const tm = e.team_members?.length ? ` + ${e.team_members.map(id => `<@${id}>`).join(", ")}` : ""; return `**${i + 1}.** <@${e.leader_id}>${tm}`; });
  const fields = [{ name: "\ud83d\udcca Status", value: `${statusEmoji} ${tourney.status.charAt(0).toUpperCase() + tourney.status.slice(1)}`, inline: true }, { name: "\ud83d\udc65 Players", value: `${entries.length} / ${tourney.max_players}`, inline: true }, { name: "\ud83e\ude91 Spots Left", value: spotsLeft <= 0 ? "\ud83d\udd34 Full!" : `${spotsLeft}`, inline: true }, { name: "\u23f0 Time", value: tourney.tournament_time ?? "TBD", inline: true }, { name: "\ud83c\udf0d Region", value: tourney.region ?? "Open", inline: true }, { name: "\ud83c\udd98 Tournament", value: `#${tourney.id}`, inline: true }];
  for (let i = 0; i < lines.length; i += 20) fields.push({ name: lines.length > 20 ? `Players (${i + 1}\u2013${Math.min(i + 20, lines.length)})` : "Registered Players", value: lines.slice(i, i + 20).join("\n"), inline: false });
  await interaction.editReply({ embeds: [{ color: 0x5865f2, title: `\ud83d\udccb Entries \u2014 ${tourney.title}`, fields, footer: { text: `${entries.length} player${entries.length !== 1 ? "s" : ""} registered` }, timestamp: new Date().toISOString() }] });
}

// ── clan handlers ─────────────────────────────────────────────────────────────

const TIER_LABELS = {
  lightblue: "\ud83d\udc51 Owner",
  green: "\ud83d\udc8e General Manager",
  yellow: "\u2b50 Experienced Pros",
  blue: "\ud83d\udd35 Pros",
  red: "\ud83d\udd34 Upper (R7+)",
  pink: "\ud83c\udfa8 New Talented Pros",
  white: "\u26aa Normal Players",
};

function parseMembers(raw) {
  return raw.split("\n").map(l => l.trim()).filter(l => l.length > 0).map(l => {
    const parts = l.split("|");
    return { username: parts[0]?.trim() ?? "", tier: (parts[1]?.trim() ?? "white").toLowerCase() };
  }).filter(m => m.username.length > 0);
}

function buildRosterEmbed(clanName, clanLogo, members) {
  const tierGroups = {};
  for (const m of members) { if (!tierGroups[m.tier]) tierGroups[m.tier] = []; tierGroups[m.tier].push(m.username); }
  const fields = Object.entries(tierGroups).sort(([a], [b]) => {
    const order = ["lightblue", "green", "yellow", "blue", "red", "pink", "white"];
    return order.indexOf(a) - order.indexOf(b);
  }).map(([tier, users]) => ({
    name: TIER_LABELS[tier] ?? tier,
    value: users.map(u => `\u2022 ${u}`).join("\n") || "None",
    inline: true,
  }));
  return { color: 0x5865f2, title: `\ud83c\udfc6 ${clanName} Clan Roster \ud83c\udfc6`, thumbnail: clanLogo ? { url: clanLogo } : undefined, description: `**Total Members:** ${members.length}`, fields, timestamp: new Date().toISOString() };
}

export async function handleClanMake(interaction) {
  const modal = new ModalBuilder().setCustomId("clan_make_modal").setTitle("Create Clan Roster");
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("clan_name").setLabel("Clan Name").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("RCL Elite")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("clan_logo").setLabel("Clan Logo URL (optional)").setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder("https://example.com/logo.png")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("members").setLabel("Members (username|tier)").setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder("Player1|lightblue\nPlayer2|green\nPlayer3|yellow\nPlayer4|blue\nPlayer5|red\nPlayer6|pink\nPlayer7|white")),
  );
  await interaction.showModal(modal);
}

export async function handleClanMakeModal(interaction) {
  const guildId = interaction.guildId ?? interaction.channelId ?? "dm";
  const ownerId = interaction.user.id;
  const clanName = getFieldValue(interaction, "clan_name") ?? "";
  const clanLogo = getFieldValue(interaction, "clan_logo") ?? "";
  const membersRaw = getFieldValue(interaction, "members") ?? "";
  const members = parseMembers(membersRaw);
  const existing = await query("SELECT id FROM clans WHERE guild_id = $1 AND owner_id = $2", [guildId, ownerId]);
  let clanId;
  if (existing.rows.length > 0) {
    clanId = existing.rows[0].id;
    await query("UPDATE clans SET clan_name = $1, clan_logo = $2, updated_at = NOW() WHERE id = $3", [clanName, clanLogo || null, clanId]);
    await query("DELETE FROM clan_members WHERE clan_id = $1", [clanId]);
  } else {
    const res = await query("INSERT INTO clans (guild_id, owner_id, clan_name, clan_logo) VALUES ($1, $2, $3, $4) RETURNING id", [guildId, ownerId, clanName, clanLogo || null]);
    clanId = res.rows[0].id;
  }
  for (const m of members) {
    await query("INSERT INTO clan_members (clan_id, guild_id, username, tier) VALUES ($1, $2, $3, $4)", [clanId, guildId, m.username, m.tier]);
  }
  const embed = buildRosterEmbed(clanName, clanLogo, members);
  await interaction.reply({ embeds: [embed] });
}

export async function handleClanRoster(interaction) {
  const owner = interaction.options.getUser("owner") ?? interaction.user;
  const guildId = interaction.guildId ?? interaction.channelId ?? "dm";
  const clanRes = await query("SELECT * FROM clans WHERE guild_id = $1 AND owner_id = $2", [guildId, owner.id]);
  if (clanRes.rows.length === 0) {
    return interaction.reply({ content: `\u274c <@${owner.id}> doesn't have a clan. Use /clan-make-2 to create one.`, ephemeral: true });
  }
  const clan = clanRes.rows[0];
  const membersRes = await query("SELECT * FROM clan_members WHERE clan_id = $1 ORDER BY id ASC", [clan.id]);
  const members = membersRes.rows.map(m => ({ username: m.username, tier: m.tier }));
  const embed = buildRosterEmbed(clan.clan_name, clan.clan_logo, members);
  await interaction.reply({ embeds: [embed] });
}

export async function handleUpdateClan(interaction) {
  const guildId = interaction.guildId ?? interaction.channelId ?? "dm";
  const ownerId = interaction.user.id;
  const clanRes = await query("SELECT * FROM clans WHERE guild_id = $1 AND owner_id = $2", [guildId, ownerId]);
  if (clanRes.rows.length === 0) {
    return interaction.reply({ content: "\u274c You don't have a clan yet. Use /clan-make-2 first.", ephemeral: true });
  }
  const clan = clanRes.rows[0];
  const membersRes = await query("SELECT * FROM clan_members WHERE clan_id = $1 ORDER BY id ASC", [clan.id]);
  const existingMembers = membersRes.rows.map(m => `${m.username}|${m.tier}`).join("\n");
  const modal = new ModalBuilder().setCustomId("update_clan_modal").setTitle("Update Clan Roster");
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("clan_name").setLabel("Clan Name").setStyle(TextInputStyle.Short).setRequired(true).setValue(clan.clan_name)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("clan_logo").setLabel("Clan Logo URL (optional)").setStyle(TextInputStyle.Short).setRequired(false).setValue(clan.clan_logo ?? "")),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("members").setLabel("Members (username|tier)").setStyle(TextInputStyle.Paragraph).setRequired(true).setValue(existingMembers)),
  );
  await interaction.showModal(modal);
}

export async function handleUpdateClanModal(interaction) {
  const guildId = interaction.guildId ?? interaction.channelId ?? "dm";
  const ownerId = interaction.user.id;
  const clanName = getFieldValue(interaction, "clan_name") ?? "";
  const clanLogo = getFieldValue(interaction, "clan_logo") ?? "";
  const membersRaw = getFieldValue(interaction, "members") ?? "";
  const clanRes = await query("SELECT id FROM clans WHERE guild_id = $1 AND owner_id = $2", [guildId, ownerId]);
  if (clanRes.rows.length === 0) {
    return interaction.reply({ content: "\u274c Clan not found. Use /clan-make-2 to create one.", ephemeral: true });
  }
  const clanId = clanRes.rows[0].id;
  const members = parseMembers(membersRaw);
  await query("UPDATE clans SET clan_name = $1, clan_logo = $2, updated_at = NOW() WHERE id = $3", [clanName, clanLogo || null, clanId]);
  await query("DELETE FROM clan_members WHERE clan_id = $1", [clanId]);
  for (const m of members) {
    await query("INSERT INTO clan_members (clan_id, guild_id, username, tier) VALUES ($1, $2, $3, $4)", [clanId, guildId, m.username, m.tier]);
  }
  const embed = buildRosterEmbed(clanName, clanLogo, members);
  await interaction.reply({ embeds: [embed] });
}

export async function handleInvite(interaction) {
  const clientId = interaction.client.user.id;
  const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${clientId}&scope=bot+applications.commands&permissions=${PermissionFlagsBits.SendMessages + PermissionFlagsBits.ManageMessages + PermissionFlagsBits.ManageRoles + PermissionFlagsBits.CreatePublicThreads + PermissionFlagsBits.ReadMessageHistory + PermissionFlagsBits.AddReactions + PermissionFlagsBits.EmbedLinks + PermissionFlagsBits.AttachFiles + PermissionFlagsBits.UseExternalEmojis}`;
  const dmUrl = `https://discord.com/oauth2/authorize?client_id=${clientId}&integration_type=1&scope=applications.commands`;
  await interaction.reply({
    embeds: [{ color: 0x5865f2, title: "\ud83e\udd16 Add Clan-tool to your Server / DMs", fields: [{ name: "\ud83c\udfe0 Add to Server", value: `[Click here](${inviteUrl})`, inline: true }, { name: "\ud83d\udcac Add to DMs / Group Chat", value: `[Click here](${dmUrl})`, inline: true }], description: "Use the links above to add the bot.\n\n**For DMs/Group Chats:** After clicking, you can also use the **App Directory** (right-click the bot \u2192 Add App).", footer: { text: "Make sure the bot has 'User Install' enabled in the Dev Portal" } }],
    ephemeral: true,
  });
}
