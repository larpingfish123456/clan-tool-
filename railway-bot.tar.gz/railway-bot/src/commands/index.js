import { REST, Routes, SlashCommandBuilder, PermissionFlagsBits, ChannelType } from "discord.js";

export function buildCommands() {
  return [
    new SlashCommandBuilder().setName("setup-entries-2").setDescription("Set the channel where players register").addChannelOption(o => o.setName("channel").setDescription("Entry channel").addChannelTypes(ChannelType.GuildText).setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("role-setup-2").setDescription("Set the role players receive on registration").addRoleOption(o => o.setName("role").setDescription("Registration role").setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("schedule-2").setDescription("Post the weekly tournament schedule").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("host-tourney-2").setDescription("Host a new tournament").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("setup-updates-2").setDescription("Set the bracket/announcement updates channel").addChannelOption(o => o.setName("channel").setDescription("Updates channel").addChannelTypes(ChannelType.GuildText).setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("bracket-2").setDescription("Generate a bracket from registered players").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("threads-2").setDescription("Create threads for each match in the current round").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("update-2").setDescription("Record a match winner and advance them").addIntegerOption(o => o.setName("match").setDescription("Match number").setRequired(true)).addUserOption(o => o.setName("winner").setDescription("The winning player").setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("over-2").setDescription("End the tournament and archive everything").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("refresh-2").setDescription("Switch the active tournament ID").addIntegerOption(o => o.setName("tournament_id").setDescription("Tournament ID to activate").setRequired(true)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("list-entries-2").setDescription("Show all registered players").addIntegerOption(o => o.setName("tournament_id").setDescription("Specific tournament ID (optional)").setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("set-players-2").setDescription("Change the max player count for a tournament").addIntegerOption(o => o.setName("max_players").setDescription("New maximum number of players / teams").setRequired(true).setMinValue(1).setMaxValue(512)).addIntegerOption(o => o.setName("tournament_id").setDescription("Tournament ID (defaults to active)").setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("sync-roles-2").setDescription("Assign the registered role to tournament players").addStringOption(o => o.setName("message_id").setDescription("Only sync entries from messages at or after this message ID").setRequired(true)).addIntegerOption(o => o.setName("tournament_id").setDescription("Tournament ID (defaults to active)").setRequired(false)).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    new SlashCommandBuilder().setName("clan-make-2").setDescription("Create a clan roster with colored tiers"),
    new SlashCommandBuilder().setName("clan-roster-2").setDescription("Display your clan roster").addUserOption(o => o.setName("owner").setDescription("Clan owner (defaults to yourself)").setRequired(false)),
    new SlashCommandBuilder().setName("update-clan-2").setDescription("Update your clan roster"),
    new SlashCommandBuilder().setName("invite-2").setDescription("Get the bot invite link"),
  ].map(c => {
    const json = c.toJSON();
    return {
      ...json,
      integration_types: [0, 1],
      contexts: [0, 1, 2],
    };
  });
}

export async function deployCommands(clientId) {
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN);
  const cmds = buildCommands();
  console.log(`[Bot] Registering ${cmds.length} commands...`);
  const data = await rest.put(Routes.applicationCommands(clientId), { body: cmds });
  console.log(`[Bot] Registered ${data.length} commands`);
}
