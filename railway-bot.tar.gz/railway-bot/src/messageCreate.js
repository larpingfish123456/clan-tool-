import { query, getGuildSettings } from "./db.js";

export async function handleMessageCreate(message) {
  if (message.author.bot || !message.guild || !message.guildId) return;
  const settings = await getGuildSettings(message.guildId);
  if (!settings?.entry_channel_id || message.channelId !== settings.entry_channel_id) return;
  if (!settings.active_tournament_id) return;

  const tourneyRes = await query("SELECT * FROM tournaments WHERE id = $1 AND status = 'open'", [settings.active_tournament_id]);
  if (!tourneyRes.rows.length) return;
  const tourney = tourneyRes.rows[0];

  const countRes = await query("SELECT COUNT(*) as count FROM entries WHERE tournament_id = $1", [settings.active_tournament_id]);
  const currentCount = parseInt(countRes.rows[0].count);

  if (currentCount >= tourney.max_players) {
    try {
      const reply = await message.reply({
        embeds: [{ color: 0xed4245, title: "🔒 Entries Closed", description: `All **${tourney.max_players}** spots for **${tourney.title}** are filled. Entries are closed!` }],
      });
      setTimeout(() => reply.delete().catch(() => {}), 15000);
    } catch (_) {}
    return;
  }

  const mentionedUsers = message.mentions.users.filter(u => !u.bot);
  const allUsers = mentionedUsers.has(message.author.id) ? mentionedUsers : mentionedUsers.set(message.author.id, message.author);
  const leaderId = message.author.id;
  const teamMembers = [...allUsers.keys()].filter(id => id !== leaderId);

  const existing = await query("SELECT id FROM entries WHERE tournament_id = $1 AND leader_id = $2", [settings.active_tournament_id, leaderId]);
  if (existing.rows.length > 0) {
    try {
      await message.react("⚠️");
      const r = await message.reply(`<@${leaderId}> you're already registered for **${tourney.title}**!`);
      setTimeout(() => r.delete().catch(() => {}), 8000);
    } catch (_) {}
    return;
  }

  await query("INSERT INTO entries (tournament_id, guild_id, leader_id, team_members, message_id) VALUES ($1,$2,$3,$4,$5)", [settings.active_tournament_id, message.guildId, leaderId, teamMembers, message.id]);

  const postCountRes = await query("SELECT COUNT(*) as count FROM entries WHERE tournament_id = $1", [settings.active_tournament_id]);
  const realCount = parseInt(postCountRes.rows[0].count);

  if (realCount > tourney.max_players) {
    await query("DELETE FROM entries WHERE tournament_id = $1 AND leader_id = $2", [settings.active_tournament_id, leaderId]);
    try {
      const reply = await message.reply({
        embeds: [{ color: 0xed4245, title: "🔒 Entries Closed", description: `All **${tourney.max_players}** spots for **${tourney.title}** are filled. Entries are closed!` }],
      });
      setTimeout(() => reply.delete().catch(() => {}), 15000);
    } catch (_) {}
    return;
  }

  if (settings.registered_role_id) {
    for (const userId of allUsers.keys()) {
      try { const member = await message.guild.members.fetch(userId); await member.roles.add(settings.registered_role_id); } catch (_) {}
    }
  }

  const remaining = tourney.max_players - realCount;
  const teamText = teamMembers.length > 0 ? ` with ${teamMembers.map(id => `<@${id}>`).join(", ")}` : "";

  try {
    await message.react("✅");
    const reply = await message.reply({
      embeds: [{
        color: 0x57f287,
        title: "✅ Registered!",
        description: `<@${leaderId}>${teamText} registered for **${tourney.title}**!`,
        fields: [
          { name: "Players", value: `${realCount} / ${tourney.max_players}`, inline: true },
          { name: "Spots Left", value: remaining <= 0 ? "🔴 Full!" : `${remaining}`, inline: true },
        ],
        footer: { text: `Entry #${realCount}` },
      }],
    });
    if (remaining <= 0) {
      await query("UPDATE tournaments SET status = 'full' WHERE id = $1", [settings.active_tournament_id]);
      setTimeout(async () => {
        try { await message.channel.send({ embeds: [{ color: 0xed4245, title: "🔒 Entries Closed!", description: `All **${tourney.max_players}** spots for **${tourney.title}** are filled!` }] }); } catch (_) {}
      }, 1000);
    }
    setTimeout(() => reply.delete().catch(() => {}), 30000);
  } catch (_) {}
}
