import pg from "pg";
const { Pool } = pg;

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

export async function query(text, params) {
  const client = await pool.connect();
  try {
    return await client.query(text, params);
  } finally {
    client.release();
  }
}

export async function getGuildSettings(guildId) {
  const res = await query("SELECT * FROM guild_settings WHERE guild_id = $1", [guildId]);
  return res.rows[0] ?? null;
}

export async function upsertGuildSettings(guildId, updates) {
  const fields = Object.keys(updates).filter((k) => k !== "guild_id");
  if (fields.length === 0) return;
  const setClauses = fields.map((f, i) => `${f} = $${i + 2}`).join(", ");
  const values = fields.map((f) => updates[f]);
  await query(
    `INSERT INTO guild_settings (guild_id, ${fields.join(", ")})
     VALUES ($1, ${fields.map((_, i) => `$${i + 2}`).join(", ")})
     ON CONFLICT (guild_id) DO UPDATE SET ${setClauses}, updated_at = NOW()`,
    [guildId, ...values],
  );
}

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS guild_settings (
      guild_id TEXT PRIMARY KEY,
      entry_channel_id TEXT,
      updates_channel_id TEXT,
      registered_role_id TEXT,
      active_tournament_id INTEGER,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS tournaments (
      id SERIAL PRIMARY KEY,
      guild_id TEXT NOT NULL,
      title TEXT NOT NULL,
      tournament_time TEXT,
      region TEXT,
      prize TEXT,
      rank_cap TEXT,
      max_players INTEGER DEFAULT 16,
      status TEXT DEFAULT 'open',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS entries (
      id SERIAL PRIMARY KEY,
      tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
      guild_id TEXT NOT NULL,
      leader_id TEXT NOT NULL,
      team_members TEXT[] DEFAULT '{}',
      team_name TEXT,
      message_id TEXT,
      registered_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS brackets (
      id SERIAL PRIMARY KEY,
      tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
      guild_id TEXT NOT NULL,
      rounds JSONB NOT NULL DEFAULT '[]',
      current_round INTEGER DEFAULT 1,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS bracket_threads (
      id SERIAL PRIMARY KEY,
      bracket_id INTEGER NOT NULL REFERENCES brackets(id) ON DELETE CASCADE,
      match_index INTEGER NOT NULL,
      round_number INTEGER NOT NULL,
      thread_id TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS schedules (
      id SERIAL PRIMARY KEY,
      guild_id TEXT NOT NULL,
      week_label TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS clans (
      id SERIAL PRIMARY KEY,
      guild_id TEXT NOT NULL,
      owner_id TEXT NOT NULL,
      clan_name TEXT NOT NULL,
      clan_logo TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS clan_members (
      id SERIAL PRIMARY KEY,
      clan_id INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
      guild_id TEXT NOT NULL,
      username TEXT NOT NULL,
      tier TEXT NOT NULL DEFAULT 'white',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  try {
    await pool.query(`ALTER TABLE entries ADD COLUMN IF NOT EXISTS message_id TEXT`);
  } catch (_) {
    // ignore
  }
  console.log("[DB] Initialized");
}
