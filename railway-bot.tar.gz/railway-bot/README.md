# Clan-tool Discord Bot

A Discord tournament bot with 17+ slash commands for hosting tournaments, managing entries, generating brackets, and clan management.

## Commands

### Tournament Commands
- `/setup-entries-2` — Set entry registration channel
- `/role-setup-2` — Set registration role
- `/schedule-2` — Post weekly tournament schedule
- `/host-tourney-2` — Host a new tournament
- `/setup-updates-2` — Set updates/bracket channel
- `/bracket-2` — Generate tournament bracket
- `/threads-2` — Create match threads
- `/update-2` — Record match winner
- `/over-2` — End tournament
- `/refresh-2` — Switch active tournament
- `/list-entries-2` — Show registered players
- `/set-players-2` — Change max player count
- `/sync-roles-2` — Bulk-assign roles to entrants

### Clan Commands
- `/clan-make-2` — Create clan roster with colored tiers
- `/clan-roster-2` — Display clan roster
- `/update-clan-2` — Update clan roster
- `/invite-2` — Get bot invite links

## Tier Colors
- lightblue → Owner
- green → General Manager
- yellow → Experienced Pros
- blue → Pros
- red → Upper (R7+)
- pink → New Talented Pros
- white → Normal Players

## Setup

1. Create a `.env` file:
```
DISCORD_BOT_TOKEN=your_token_here
DATABASE_URL=postgresql://user:pass@host:5432/dbname
```

2. Deploy to Railway:
   - Create a new project on Railway
   - Add a PostgreSQL database
   - Add your `DISCORD_BOT_TOKEN` as an environment variable
   - Connect to GitHub repo
   - Deploy

3. Enable "User Install" in Discord Developer Portal for DMs support.
